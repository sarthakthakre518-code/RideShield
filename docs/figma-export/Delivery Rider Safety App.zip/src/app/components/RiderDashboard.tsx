import { Gauge, Shield, MapPin, AlertTriangle, Menu, Bell } from 'lucide-react';

interface RiderDashboardProps {
  onNavigate: (screen: string) => void;
}

export function RiderDashboard({ onNavigate }: RiderDashboardProps) {
  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <button className="p-2">
            <Menu className="w-6 h-6 text-gray-900" />
          </button>
          <h1 className="text-gray-900">Dashboard</h1>
          <button className="p-2">
            <Bell className="w-6 h-6 text-gray-900" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-4 space-y-4">
        {/* Status Card */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-3">
            <span className="text-gray-700">Status</span>
            <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
              Active
            </span>
          </div>
          <p className="text-gray-500">Rider ID: #12345</p>
        </div>

        {/* Speed Monitor */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Gauge className="w-5 h-5 text-gray-600" />
              <span className="text-gray-900">Current Speed</span>
            </div>
          </div>
          
          {/* Speed Display */}
          <div className="flex items-center justify-center mb-6">
            <div className="relative w-40 h-40">
              {/* Outer circle */}
              <div className="absolute inset-0 rounded-full border-8 border-gray-200"></div>
              {/* Progress circle */}
              <div className="absolute inset-0 rounded-full border-8 border-gray-900" style={{ 
                clipPath: 'polygon(50% 50%, 50% 0%, 100% 0%, 100% 100%, 0% 100%, 0% 0%, 50% 0%)',
                transform: 'rotate(108deg)'
              }}></div>
              {/* Center content */}
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl text-gray-900">42</span>
                <span className="text-gray-500">km/h</span>
              </div>
            </div>
          </div>
          
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Safe: 0-60 km/h</span>
            <span className="text-gray-500">Max: 80 km/h</span>
          </div>
        </div>

        {/* Safety Score */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-gray-600" />
              <span className="text-gray-900">Safety Score</span>
            </div>
            <span className="text-gray-900">87/100</span>
          </div>
          
          {/* Progress Bar */}
          <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
            <div className="bg-gray-900 h-3 rounded-full" style={{ width: '87%' }}></div>
          </div>
          
          <p className="text-gray-500 mt-3">Great job! Keep it safe</p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={() => onNavigate('routes')}
            className="bg-white rounded-lg border border-gray-200 p-6 flex flex-col items-center gap-3"
          >
            <MapPin className="w-8 h-8 text-gray-600" />
            <span className="text-gray-900">Safe Routes</span>
          </button>
          
          <button
            onClick={() => onNavigate('sos')}
            className="bg-white rounded-lg border border-gray-200 p-6 flex flex-col items-center gap-3"
          >
            <AlertTriangle className="w-8 h-8 text-gray-600" />
            <span className="text-gray-900">SOS Alert</span>
          </button>
        </div>

        {/* Today's Stats */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-gray-900 mb-4">Today's Stats</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl text-gray-900 mb-1">24</div>
              <div className="text-gray-500">Deliveries</div>
            </div>
            <div className="text-center border-l border-r border-gray-200">
              <div className="text-2xl text-gray-900 mb-1">156</div>
              <div className="text-gray-500">km Driven</div>
            </div>
            <div className="text-center">
              <div className="text-2xl text-gray-900 mb-1">6.5</div>
              <div className="text-gray-500">Hours</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
