import { LogIn } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (role: 'rider' | 'admin') => void;
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const handleSubmit = (e: React.FormEvent, role: 'rider' | 'admin') => {
    e.preventDefault();
    onLogin(role);
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <h1 className="text-center text-gray-900">RiderSafe</h1>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col justify-center px-6">
        <div className="w-full max-w-sm mx-auto">
          {/* Logo/Icon */}
          <div className="flex justify-center mb-8">
            <div className="w-20 h-20 rounded-full bg-gray-200 flex items-center justify-center">
              <LogIn className="w-10 h-10 text-gray-600" />
            </div>
          </div>

          <h2 className="text-center mb-2 text-gray-900">Welcome Back</h2>
          <p className="text-center text-gray-500 mb-8">Login to continue</p>

          {/* Login Form */}
          <form onSubmit={(e) => handleSubmit(e, 'rider')} className="space-y-4">
            <div>
              <label className="block text-gray-700 mb-2">Phone Number</label>
              <input
                type="tel"
                placeholder="+1 234 567 8900"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-white text-gray-900 placeholder:text-gray-400"
              />
            </div>

            <div>
              <label className="block text-gray-700 mb-2">PIN</label>
              <input
                type="password"
                placeholder="••••"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-white text-gray-900"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-gray-900 text-white py-3 rounded-lg mt-6"
            >
              Login as Rider
            </button>

            <button
              type="button"
              onClick={(e) => handleSubmit(e, 'admin')}
              className="w-full bg-white text-gray-900 py-3 rounded-lg border border-gray-300"
            >
              Login as Admin
            </button>
          </form>

          <p className="text-center text-gray-500 mt-6">Forgot PIN?</p>
        </div>
      </div>
    </div>
  );
}
