import { MapPin, ChevronLeft, Navigation, AlertCircle, TrendingUp, Clock } from 'lucide-react';

interface RoutesScreenProps {
  onBack: () => void;
}

export function RoutesScreen({ onBack }: RoutesScreenProps) {
  const routes = [
    {
      id: 1,
      name: 'Route A - Main Highway',
      distance: '12.4 km',
      time: '18 min',
      safetyScore: 92,
      incidents: 2,
      recommended: true
    },
    {
      id: 2,
      name: 'Route B - City Center',
      distance: '10.8 km',
      time: '25 min',
      safetyScore: 78,
      incidents: 7,
      recommended: false
    },
    {
      id: 3,
      name: 'Route C - Bypass Road',
      distance: '15.2 km',
      time: '20 min',
      safetyScore: 85,
      incidents: 4,
      recommended: false
    }
  ];

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2">
            <ChevronLeft className="w-6 h-6 text-gray-900" />
          </button>
          <h1 className="text-gray-900">Safe Routes</h1>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-4 space-y-4">
        {/* Destination */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <label className="block text-gray-700 mb-2">Destination Address</label>
          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
            <MapPin className="w-5 h-5 text-gray-600" />
            <input
              type="text"
              placeholder="Enter delivery address"
              defaultValue="456 Oak Avenue, Westside"
              className="flex-1 bg-transparent text-gray-900 outline-none"
            />
          </div>
        </div>

        {/* Map Placeholder */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="bg-gray-100 rounded-lg h-48 flex items-center justify-center relative overflow-hidden">
            {/* Simple map visualization */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-gray-400">
                <Navigation className="w-12 h-12 mx-auto mb-2" />
                <p className="text-sm">Route Map</p>
              </div>
            </div>
            {/* Route lines visualization */}
            <svg className="absolute inset-0 w-full h-full" style={{ opacity: 0.3 }}>
              <path d="M 20 150 Q 100 100, 180 140" stroke="#1f2937" strokeWidth="3" fill="none" />
              <path d="M 20 150 Q 100 120, 180 140" stroke="#6b7280" strokeWidth="2" fill="none" strokeDasharray="5,5" />
              <path d="M 20 150 Q 100 80, 180 140" stroke="#9ca3af" strokeWidth="2" fill="none" strokeDasharray="5,5" />
            </svg>
          </div>
        </div>

        {/* Route Options */}
        <div className="space-y-3">
          <h3 className="text-gray-900">Available Routes</h3>
          
          {routes.map((route) => (
            <div
              key={route.id}
              className={`bg-white rounded-lg border-2 p-4 ${
                route.recommended ? 'border-gray-900' : 'border-gray-200'
              }`}
            >
              {route.recommended && (
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-4 h-4 text-gray-900" />
                  <span className="text-sm text-gray-900">Recommended - Safest Route</span>
                </div>
              )}
              
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h4 className="text-gray-900 mb-1">{route.name}</h4>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <Navigation className="w-4 h-4" />
                      {route.distance}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {route.time}
                    </span>
                  </div>
                </div>
              </div>

              {/* Safety Score */}
              <div className="mb-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-700">Safety Score</span>
                  <span className="text-sm text-gray-900">{route.safetyScore}/100</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${
                      route.safetyScore >= 85 ? 'bg-gray-900' : 'bg-gray-400'
                    }`}
                    style={{ width: `${route.safetyScore}%` }}
                  ></div>
                </div>
              </div>

              {/* Incidents */}
              <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                <AlertCircle className="w-4 h-4" />
                <span>{route.incidents} incidents reported this week</span>
              </div>

              {/* Action Button */}
              <button
                className={`w-full py-2 rounded-lg ${
                  route.recommended
                    ? 'bg-gray-900 text-white'
                    : 'bg-gray-100 text-gray-900'
                }`}
              >
                {route.recommended ? 'Start Navigation' : 'Select Route'}
              </button>
            </div>
          ))}
        </div>

        {/* Safety Info */}
        <div className="bg-gray-100 rounded-lg p-4">
          <h4 className="text-gray-900 mb-2">Route Safety Factors</h4>
          <ul className="space-y-1 text-gray-700 text-sm">
            <li>• Traffic density and patterns</li>
            <li>• Historical accident data</li>
            <li>• Road conditions and quality</li>
            <li>• Weather and visibility</li>
            <li>• Time of day considerations</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
