import { AlertTriangle, Phone, MapPin, ChevronLeft, Shield } from 'lucide-react';
import { useState } from 'react';

interface SOSScreenProps {
  onBack: () => void;
}

export function SOSScreen({ onBack }: SOSScreenProps) {
  const [sosActivated, setSosActivated] = useState(false);
  const [accidentDetected, setAccidentDetected] = useState(true);

  const activateSOS = () => {
    setSosActivated(true);
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2">
            <ChevronLeft className="w-6 h-6 text-gray-900" />
          </button>
          <h1 className="text-gray-900">Emergency & Safety</h1>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-4 space-y-4">
        {/* Accident Detection Alert */}
        {accidentDetected && !sosActivated && (
          <div className="bg-red-50 border-2 border-red-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
              <div className="flex-1">
                <h3 className="text-red-900 mb-1">Accident Detected</h3>
                <p className="text-red-700 text-sm mb-3">
                  Sudden impact detected at 2:34 PM
                </p>
                <button
                  onClick={activateSOS}
                  className="w-full bg-red-600 text-white py-2 rounded-lg"
                >
                  I Need Help - Send SOS
                </button>
                <button
                  onClick={() => setAccidentDetected(false)}
                  className="w-full bg-white text-red-600 py-2 rounded-lg border border-red-200 mt-2"
                >
                  I'm OK - Dismiss
                </button>
              </div>
            </div>
          </div>
        )}

        {/* SOS Activated Status */}
        {sosActivated && (
          <div className="bg-red-600 text-white rounded-lg p-6">
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mb-4 animate-pulse">
                <AlertTriangle className="w-8 h-8 text-red-600" />
              </div>
              <h2 className="mb-2">SOS ACTIVATED</h2>
              <p className="mb-4">Help is on the way</p>
              <div className="bg-red-700 rounded-lg p-3 w-full">
                <p className="text-sm">Emergency contacts notified</p>
                <p className="text-sm">ETA: 8 minutes</p>
              </div>
            </div>
          </div>
        )}

        {/* Manual SOS Button */}
        {!sosActivated && (
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="text-center">
              <h3 className="text-gray-900 mb-2">Emergency SOS</h3>
              <p className="text-gray-500 mb-6">
                Press and hold for 3 seconds to activate
              </p>
              <button
                onClick={activateSOS}
                className="w-32 h-32 mx-auto bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg"
              >
                <AlertTriangle className="w-12 h-12" />
              </button>
              <p className="text-gray-500 mt-4 text-sm">
                This will alert emergency contacts and nearby riders
              </p>
            </div>
          </div>
        )}

        {/* Current Location */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center gap-3 mb-3">
            <MapPin className="w-5 h-5 text-gray-600" />
            <h3 className="text-gray-900">Current Location</h3>
          </div>
          <div className="bg-gray-100 rounded-lg p-4 mb-3">
            <div className="text-gray-700 mb-1">123 Main Street</div>
            <div className="text-gray-500 text-sm">Downtown, City Center</div>
          </div>
          <button className="text-gray-900 border border-gray-300 py-2 px-4 rounded-lg w-full">
            Share Live Location
          </button>
        </div>

        {/* Emergency Contacts */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-gray-900 mb-4">Emergency Contacts</h3>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                  <Shield className="w-5 h-5 text-gray-600" />
                </div>
                <div>
                  <div className="text-gray-900">Emergency Services</div>
                  <div className="text-gray-500 text-sm">911</div>
                </div>
              </div>
              <button className="p-2">
                <Phone className="w-5 h-5 text-gray-600" />
              </button>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                <div>
                  <div className="text-gray-900">Fleet Manager</div>
                  <div className="text-gray-500 text-sm">+1 234 567 8900</div>
                </div>
              </div>
              <button className="p-2">
                <Phone className="w-5 h-5 text-gray-600" />
              </button>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                <div>
                  <div className="text-gray-900">Personal Contact</div>
                  <div className="text-gray-500 text-sm">+1 234 567 8901</div>
                </div>
              </div>
              <button className="p-2">
                <Phone className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>
        </div>

        {/* Safety Tips */}
        <div className="bg-gray-100 rounded-lg p-4">
          <h3 className="text-gray-900 mb-2">Safety Tips</h3>
          <ul className="space-y-2 text-gray-700 text-sm">
            <li>• Keep your phone charged at all times</li>
            <li>• Share your live location during deliveries</li>
            <li>• Wear protective gear always</li>
            <li>• Follow traffic rules strictly</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
