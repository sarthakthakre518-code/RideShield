import { Users, AlertTriangle, TrendingUp, Activity, ChevronLeft, Search } from 'lucide-react';

interface AdminDashboardProps {
  onBack: () => void;
}

export function AdminDashboard({ onBack }: AdminDashboardProps) {
  const activeRiders = [
    { id: '12345', name: 'John Doe', speed: 42, safetyScore: 87, status: 'active' },
    { id: '12346', name: 'Jane Smith', speed: 38, safetyScore: 92, status: 'active' },
    { id: '12347', name: 'Mike Johnson', speed: 65, safetyScore: 71, status: 'warning' },
    { id: '12348', name: 'Sarah Williams', speed: 35, safetyScore: 95, status: 'active' }
  ];

  const recentIncidents = [
    { id: 1, rider: 'Mike Johnson', type: 'Speeding', time: '10 min ago', severity: 'warning' },
    { id: 2, rider: 'John Doe', type: 'Hard Brake', time: '25 min ago', severity: 'info' },
    { id: 3, rider: 'Alex Brown', type: 'SOS Alert', time: '1 hour ago', severity: 'critical' }
  ];

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2">
            <ChevronLeft className="w-6 h-6 text-gray-900" />
          </button>
          <h1 className="text-gray-900">Admin Dashboard</h1>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-4 space-y-4">
        {/* Stats Overview */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="flex items-center gap-2 mb-2">
              <Users className="w-5 h-5 text-gray-600" />
              <span className="text-gray-700">Active Riders</span>
            </div>
            <div className="text-3xl text-gray-900">42</div>
            <div className="text-sm text-gray-500 mt-1">+5 from yesterday</div>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-5 h-5 text-gray-600" />
              <span className="text-gray-700">Avg Safety</span>
            </div>
            <div className="text-3xl text-gray-900">84</div>
            <div className="text-sm text-gray-500 mt-1">Score out of 100</div>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-5 h-5 text-gray-600" />
              <span className="text-gray-700">Incidents</span>
            </div>
            <div className="text-3xl text-gray-900">12</div>
            <div className="text-sm text-gray-500 mt-1">Today</div>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-5 h-5 text-gray-600" />
              <span className="text-gray-700">Total Trips</span>
            </div>
            <div className="text-3xl text-gray-900">856</div>
            <div className="text-sm text-gray-500 mt-1">Today</div>
          </div>
        </div>

        {/* Search Riders */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
            <Search className="w-5 h-5 text-gray-600" />
            <input
              type="text"
              placeholder="Search riders by ID or name"
              className="flex-1 bg-transparent text-gray-900 outline-none placeholder:text-gray-400"
            />
          </div>
        </div>

        {/* Active Riders */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-gray-900 mb-4">Active Riders</h3>
          
          <div className="space-y-3">
            {activeRiders.map((rider) => (
              <div
                key={rider.id}
                className="p-3 bg-gray-50 rounded-lg border border-gray-200"
              >
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <div className="text-gray-900">{rider.name}</div>
                    <div className="text-sm text-gray-500">ID: #{rider.id}</div>
                  </div>
                  <span
                    className={`px-2 py-1 rounded-full text-xs ${
                      rider.status === 'warning'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-green-100 text-green-800'
                    }`}
                  >
                    {rider.status === 'warning' ? 'Warning' : 'Active'}
                  </span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">Speed:</span>
                    <span className={`ml-2 ${rider.speed > 60 ? 'text-red-600' : 'text-gray-900'}`}>
                      {rider.speed} km/h
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">Safety:</span>
                    <span className="text-gray-900 ml-2">{rider.safetyScore}/100</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button className="w-full mt-3 py-2 text-gray-900 border border-gray-300 rounded-lg">
            View All Riders
          </button>
        </div>

        {/* Recent Incidents */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-gray-900 mb-4">Recent Incidents</h3>
          
          <div className="space-y-3">
            {recentIncidents.map((incident) => (
              <div
                key={incident.id}
                className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg border border-gray-200"
              >
                <div
                  className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${
                    incident.severity === 'critical'
                      ? 'bg-red-600'
                      : incident.severity === 'warning'
                      ? 'bg-yellow-600'
                      : 'bg-blue-600'
                  }`}
                ></div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-gray-900">{incident.type}</span>
                    <span className="text-sm text-gray-500">{incident.time}</span>
                  </div>
                  <div className="text-sm text-gray-600">{incident.rider}</div>
                </div>
              </div>
            ))}
          </div>

          <button className="w-full mt-3 py-2 text-gray-900 border border-gray-300 rounded-lg">
            View All Incidents
          </button>
        </div>

        {/* Fleet Performance */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-gray-900 mb-4">Fleet Performance (Today)</h3>
          
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-700">On-time Deliveries</span>
                <span className="text-gray-900">94%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-gray-900 h-2 rounded-full" style={{ width: '94%' }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-700">Safe Driving</span>
                <span className="text-gray-900">87%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-gray-900 h-2 rounded-full" style={{ width: '87%' }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-700">Customer Rating</span>
                <span className="text-gray-900">4.8/5.0</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-gray-900 h-2 rounded-full" style={{ width: '96%' }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
