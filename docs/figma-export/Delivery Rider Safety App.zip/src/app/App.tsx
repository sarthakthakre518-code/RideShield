import { useState } from 'react';
import { LoginScreen } from '@/app/components/LoginScreen';
import { RiderDashboard } from '@/app/components/RiderDashboard';
import { SOSScreen } from '@/app/components/SOSScreen';
import { RoutesScreen } from '@/app/components/RoutesScreen';
import { AdminDashboard } from '@/app/components/AdminDashboard';

type Screen = 'login' | 'rider-dashboard' | 'sos' | 'routes' | 'admin-dashboard';
type UserRole = 'rider' | 'admin' | null;

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('login');
  const [userRole, setUserRole] = useState<UserRole>(null);

  const handleLogin = (role: 'rider' | 'admin') => {
    setUserRole(role);
    if (role === 'rider') {
      setCurrentScreen('rider-dashboard');
    } else {
      setCurrentScreen('admin-dashboard');
    }
  };

  const handleNavigate = (screen: string) => {
    setCurrentScreen(screen as Screen);
  };

  const handleBack = () => {
    if (userRole === 'rider') {
      setCurrentScreen('rider-dashboard');
    } else {
      setCurrentScreen('admin-dashboard');
    }
  };

  const handleLogout = () => {
    setCurrentScreen('login');
    setUserRole(null);
  };

  return (
    <div className="size-full flex items-center justify-center bg-gray-100">
      {/* Mobile Frame */}
      <div className="w-full max-w-[400px] h-full max-h-[800px] bg-white shadow-2xl overflow-hidden flex flex-col">
        {currentScreen === 'login' && <LoginScreen onLogin={handleLogin} />}
        {currentScreen === 'rider-dashboard' && (
          <RiderDashboard onNavigate={handleNavigate} />
        )}
        {currentScreen === 'sos' && <SOSScreen onBack={handleBack} />}
        {currentScreen === 'routes' && <RoutesScreen onBack={handleBack} />}
        {currentScreen === 'admin-dashboard' && <AdminDashboard onBack={handleLogout} />}
      </div>
    </div>
  );
}
