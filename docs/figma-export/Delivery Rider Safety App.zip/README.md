
  # Delivery Rider Safety App

  This is a code bundle for Delivery Rider Safety App. The original project is available at https://www.figma.com/design/DCYhd9GHwmuowCuraL7RlR/Delivery-Rider-Safety-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  